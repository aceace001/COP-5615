﻿open System
open Akka.FSharp
open Akka
open Akka.Actor
open Akka.Configuration
open System.Threading
open System.Collections.Generic
open MathNet.Numerics.Distributions 
open Akka.TestKit

let system = System.create "system" (Configuration.defaultConfig())

let tweetDB = new Dictionary<string, (String * list<string>) > ()

let relationDB = new Dictionary<string,list<string>>()

let numberOfUser=2000

let normalDist = new Normal(50.0, 10.0) 

type Operation=
    | Register of string
    | Tweet of string 
    | Hashtag of string 
    | Mention of string
    | Subscribe of string
    | Unsubscribe of string
    | Login of string
    | Logout of string
    | Query of string
    | Deliver of string
    | Print of string

type message2=
    | Simulate of string
    | Log of string 
    | Logo of string 
    | Result of string
    | Tweets of string
    | ReTweets of string
    | FollowerRe of string
    
let rec remove n lst = 
    match lst with
    | h::tl when h = n -> tl
    | h::tl -> h :: (remove n tl)
    | []    -> []
 

let register(aa) =
    tweetDB.Add(aa, ("Offline",[]))
    relationDB.Add(aa, [])


let loginNout(name)(status) =
    let mutable temp = snd (tweetDB.Item(name))
    if status = 1 then
        tweetDB.Item(name) <- ("Online", temp)
    elif status = 0 then
        tweetDB.Item(name) <- ("Offline", temp)
        
let tweet(name) (message) =
    let temp = snd(tweetDB.Item(name)) @ [message]
    tweetDB.Item(name) <- ("Online", temp)



let subNunsub(name)(aa)(sub)=
    let mutable temp = relationDB.Item(name)
    if sub = 1 then      // subscribe
//        let mutable temp = relationDB.Item(name)
        temp <- temp @ [aa]
    elif sub = 0 then    // unsubscribe 
        temp <- remove aa (relationDB.Item(name))
    relationDB.Item(name) <- temp


let tagNmention(content:string) =
    for name in tweetDB.Keys do
        for each in (snd (tweetDB.Item(name)) ) do
            if (each.Contains content) then
               if content.[0] = '#' then                // tag
                   printfn "%s" each
               if content.[0] = '@' then                // mention 
                   printfn "%s: %s" name each
let query(name) =
    for item in relationDB.Item(name) do
            printfn "%s" item    ///these could have problems, online later
let deliver(aa) =
    printfn" "
    if (relationDB.ContainsKey aa) then
        let watch_list = relationDB.[aa]        
        for wtc in watch_list do
            for each1 in snd (tweetDB.[wtc]) do
                printfn"%s: %s" wtc each1
    for each2 in (snd (tweetDB.[aa])) do
        printfn"%s: %s" aa each2

let output() =
    printfn"*******************************************"
    printfn"Please select one of the following functions(only enter the number):"
    printfn"1.Tweet"
    printfn"2.My subscription"
    printfn"3.Hashtag query"
    printfn"4.Mention me"
    printfn"5.Subscribe"
    printfn"6.Unsubscribe"
    printfn"7.Retweet"
    printfn"8.Logout"
    printfn"*******************************************"
    
let Tweeter (mailbox : Actor<_>) = 
    let name = mailbox.Self.Path.Name
    let rec loop () = actor {
        let! msg = mailbox.Receive()
        match msg with
        | Register aa ->
            register(aa)
        | Tweet message ->
            tweet(name)(message)
        | Login aa ->
            loginNout(name)(1)
        | Subscribe aa ->      
            subNunsub(name)(aa)(1)
        | Unsubscribe aa ->
            subNunsub(name)(aa)(0)
        | Logout aa ->
            loginNout(name)(0)
        | Hashtag tag ->
//            printfn("tag: %A") tag
            tagNmention(tag)
        | Mention mentions ->
//            printfn("mentions: %A") mentions 
            tagNmention(mentions)
        | Query aa ->
            query(name)
        | Deliver aa ->
            deliver(aa)
        | Print aa ->
            output()
        return! loop ()
      }
    loop ()
    
let actorArray = Array.create numberOfUser (Tweeter |> spawn system "tes1234")

{0..(numberOfUser-1)} |> Seq.iter (fun a ->
           //let m=(ranaa 10)
           actorArray.[a] <- Tweeter |> spawn system (string a)
)

let stopWatch=System.Diagnostics.Stopwatch.StartNew()
    
Thread.Sleep(500)  


let r = Random()
let ranstring n = 
    let chars = Array.concat([[|'a' .. 'z'|];[|'A' .. 'Z'|];[|'0' .. '9'|]])
    let s = Array.length chars in String(Array.init n (fun _ -> chars.[r.Next s])) 


let randomt=
    let rand = new Random()
    let ran = rand.Next(0,3)
    let ran1 = rand.Next(1,10)
    let ran2 = rand.Next(1,5)
    let ran3 = rand.Next(0,5)
    let mutable strs = ""
    strs <- strs + (ranstring ran1)
    for i = 0 to ran do
        strs <- strs + "#" + (ranstring ran2)
    for i = 0 to ran3 do
        strs <- strs + "@" + (ranstring ran2)
    //printfn "%s" strs
    strs

let simula = 
    for i = 0 to numberOfUser - 1 do
        tweetDB.Add((string i), ("Offline",[]))
        relationDB.Add((string i), [])

        //Seq.iter (printfn "%A") tweetDB

let log1 n = 
    for i = 0 to numberOfUser - 1 do
        let a = Random().Next(numberOfUser)
        if n = 1 then
            actorArray.[a] <! Login " " 
        else 
            actorArray.[a] <! Logout " "
        
let Tweetss = 
    for i = 0 to numberOfUser - 1 do
        let online = fst (tweetDB.Item(string(i)))
        if online = "Online" then
           actorArray.[i] <! Tweet randomt
    
let Simulator (mailbox : Actor<_>) = 
    let name = mailbox.Self.Path.Name
    let rec loop () = actor {
            let! msg = mailbox.Receive()
            match msg with
            | Simulate aa->
                simula
            | Log aa ->
                log1 1
            | Logo aa ->
                log1 2  
            | Tweets aa->
                Tweetss
            | ReTweets aa ->
                let mutable num_sub = normalDist.Sample() 
                let mutable num_sub_int = int(num_sub)
                let mutable new_num_twe = int(num_sub/5.0)
                let rnd=new Random()
                for i = 0 to numberOfUser - 1 do
                    num_sub <- normalDist.Sample() 
                    num_sub_int <- int(num_sub)
                    new_num_twe <- int(num_sub/5.0)
                    let mutable his_sub = relationDB.[string(i)]                    

                    if new_num_twe > 0 then
                        for num = 1 to new_num_twe do
                            actorArray.[i] <! Tweet randomt

                    while(num_sub_int>0) do
                        let mutable n=rnd.Next(numberOfUser)
                        while(((List.exists (fun elem -> elem = string n) his_sub) = true) ) do
                            n <- rnd.Next(numberOfUser)
                        his_sub <- his_sub @ [string n]

                        num_sub_int <- num_sub_int - 1

                    relationDB.Item(string(i)) <- his_sub
            

            | Result aa-> 
                let mutable numonline=0
                let mutable tweetsnum=0
                let mutable subnum=0
                let mutable mennum = 0
                let mutable hashnum = 0
                let mutable counts = 0
                let mutable counts1 = 0
                for i = 0 to numberOfUser - 1 do
                         let online= fst (tweetDB.Item(string(i)))
                         if(online="Online") then 
                            numonline <- numonline+1
                         let tweets= snd (tweetDB.Item(string(i)))
                         let subscribers = relationDB.Item(string(i))
                         tweetsnum <- tweetsnum + tweets.Length
                         subnum <- subnum + subscribers.Length
                         let tt = tweets.[1]
                         
                         let x = '#'
                         let y = '@'
                         let count j e =
                             Seq.length(Seq.filter (fun j' -> j' = j) e)
                         counts <- (count x tt)
                         counts1 <- (count y tt)   
                       
                         mennum <- mennum + counts
                         hashnum <- hashnum + counts1

                
                printfn "number of users: %i " numberOfUser
                printfn "number of current online users: %i " numonline
                printfn "number of disconnected users: %i " (numberOfUser - numonline)
                printfn "number of tweets by all users: %i " tweetsnum
                printfn "number of subscribes by all users: %i " subnum
                printfn "number of mentions by all users: %i " mennum
                printfn "number of hashtags by all users: %i " hashnum

          }
    loop ()


let main =
    let mutable get_message = Console.ReadLine()
    
    if get_message = "test" then
        tweetDB.Add("test1", ("Offline", ["First_tweet"; "Second_tweet#tag1";"Third_tweet@test2"]))    
        tweetDB.Add("test2", ("Offline", ["First_tweet_2"; "Second_tweet_2#tag1";"Third_tweet_2@test1"]))
        tweetDB.Add("test3", ("Offline", ["First_tweet_3"; "Second_tweet_3#tag1";"Third_tweet_2@test1"]))
        tweetDB.Add("test4", ("Offline", ["First_tweet_4"; "Second_tweet_4#tag1";"Third_tweet_2@test1"])) 
        relationDB.Add("test1", ["test2"; "test3"])
        relationDB.Add("test2", ["test4"])
        
        printfn"*******************************************************************************************"
        printfn"Welcome Back! Please Login or Register to enter your account (input number only):"
        printfn"1.Register"
        printfn"2.Login"
        printfn"*******************************************************************************************"
  
        let mutable input = Console.ReadLine()
        let input2() =
            printfn"Please input your name:"
            let mutable u_name = Console.ReadLine()
            
            let user2=spawn system u_name Tweeter
            user2 <! Login u_name
            System.Console.Clear()
            printfn"***************************************************"
            printfn"Hello %s, welcome back!" u_name

            user2 <! Deliver u_name  

            user2 <! Print u_name

            let mutable choice = Console.ReadLine()
            while(choice<>"8") do
                if choice = "1" then
                    printfn"Please enter your tweet:"
                    let tw_msg = Console.ReadLine()
                    System.Console.Clear()
                    user2<! Tweet tw_msg
                    user2 <! Deliver u_name
                if choice = "2" then
                    if relationDB.ContainsKey u_name = true then
                        System.Console.Clear()
                        printfn"***************************************************"
                        printfn"Below is your subscriptions: "
                        let all_sub = relationDB.[u_name]
                        user2<!Query " "
                    else
                        printfn"No subscription."
                        printfn" "
                if choice = "3" then
                    printfn"Please enter the tag(Start with #):"
                    let ta_msg = Console.ReadLine() 
                    System.Console.Clear()
                    printfn"***************************************************"
                    printfn"Below is the tweet(s) with %A: " ta_msg
                    user2<!Hashtag ta_msg
                if choice = "4" then
                    let tmp0 = "@" + u_name
                    System.Console.Clear()
                    printfn"***************************************************"
                    printfn"Below is the result(s) mentioned you: "
                    user2<!Mention tmp0
                if choice = "5" then
                    printfn"Please enter the name:"
                    let new_sub = Console.ReadLine()
                    if tweetDB.ContainsKey new_sub = true then
                        user2<!Subscribe new_sub
                        System.Console.Clear()
                        printfn"You subscribe %A successfully." new_sub 
                        printfn" "
                    else
                        System.Console.Clear()
                        printfn"***************************************************"
                        printfn"The name does not exist, please online that again!"
                        printfn"***************************************************"
                if choice = "6" then
                    printfn"Please enter the name:"
                    let un_sub = Console.ReadLine()
                    if tweetDB.ContainsKey un_sub = true then
                        user2<!Unsubscribe un_sub
                        System.Console.Clear()
                        printfn"You unsubscribe %A successfully." un_sub 
                        printfn" "
                    else
                        System.Console.Clear()
                        printfn"***************************************************"
                        printfn"The name does not exist, please enter that again!"
                        printfn"***************************************************"
                if choice = "7" then
                    user2 <! Deliver u_name
                    printfn"Please enter full name to retweet their tweet(s):"
                    printfn" "
                    let re_user = Console.ReadLine()
                    if tweetDB.ContainsKey re_user = true then
                        let watch_list = snd (tweetDB.[re_user])     
                        if  watch_list.Length <> 0 then
                            for i = 1 to watch_list.Length do
                                //for each1 in snd (tweetDB.[wtc]) do
                                printfn"%d: %s" i watch_list.[i-1]
                        printfn"Please enter the number of the tweets that you want to retweet:"
                        let re_num = Console.ReadLine()
                        let re_tw = re_user + ": " + watch_list.[int(re_num) - 1]
                        user2<!Tweet re_tw
                        user2 <! Deliver u_name
                    else
                        printfn"***************************************************"
                        printfn"name does not exist, please try that again!"
                        printfn"***************************************************"

                user2 <! Print u_name
                choice <- Console.ReadLine()

            user2<!Logout u_name
            printfn"Bye."
        let mutable flag = 1
        while flag = 1 do
            if input = "1" then
                printfn"Please create your name(must contain letters)"
                let mutable reg_name = Console.ReadLine()
                
                let sys = reg_name + "ac"
                let user=spawn system sys Tweeter
                user <! Register reg_name
                System.Console.Clear()
                printfn"Welcome, %s! Your account was successfully created." reg_name
                printfn" "
                printfn"Please select functions:"
                printfn"1.Register"
                printfn"2.Login"
                input <- Console.ReadLine()
            elif input  = "2" then
                input2()
                flag <- 0 
            else
                printfn"you can only input 1 or 2 to register to login"
                
    elif get_message = "simulate" then

        let simulator=spawn system "t0" Simulator
        Thread.Sleep(500)   
        simulator <! Simulate " "
        Thread.Sleep(500)   
        let simulator1=spawn system "t1" Simulator
        Thread.Sleep(500)   
        simulator1 <! ReTweets " "
        Thread.Sleep(500)   
        let simulator2=spawn system "t2" Simulator
        Thread.Sleep(500)   
        simulator2 <! Tweets " "
        Thread.Sleep(500)
        let simulator3=spawn system "t3" Simulator
        Thread.Sleep(500)   
        simulator3 <! Log " "
        Thread.Sleep(500) 
        let simulator4=spawn system "t4" Simulator
        Thread.Sleep(500)   
        simulator4 <! Logo " "
        Thread.Sleep(500) 
        let simulator5=spawn system "t5" Simulator
        Thread.Sleep(500)   
        simulator5 <! Result " "

        stopWatch.Stop
        let result=stopWatch.Elapsed.TotalMilliseconds
        printfn "The total running time: %f ms" result

    else 
        printfn"Wrong input."

    0